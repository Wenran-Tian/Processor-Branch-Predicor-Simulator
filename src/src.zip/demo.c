#include<stdio.h>
#include<stdlib.h>

main(){
	printf("It's worked!");
}
